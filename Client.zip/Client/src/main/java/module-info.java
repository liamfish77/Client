module edu.lawrence.pongclient {
    requires javafx.controls;
    exports edu.lawrence.pongclient;
}
